export { default as LoginBg } from "./img/loginBg.jpg";
export { default as Logo } from "./img/logo.png";
export { default as Avatar } from "./img/avatar.png";
export { default as Mango } from "./img/mango.png";
export { default as Delivery } from "./img/delivery.png";
export { default as HeroBg } from "./img/heroBg.png";
export { default as Bill } from "./img/bill.jpg";
